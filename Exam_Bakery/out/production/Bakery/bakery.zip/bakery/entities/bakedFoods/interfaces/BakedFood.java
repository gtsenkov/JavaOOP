package bakery.entities.bakedFoods.interfaces;

public interface BakedFood {
    String getName();

    double getPortion();

    double getPrice();
}

package HierarchicalInheritance;

public class Cat extends Animal {

    public void meow() {
        System.out.println("meowing");
    }
}

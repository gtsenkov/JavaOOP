package telephonyMy;

public interface Browsable {
    String browse();
}

package telephonyMy;

public interface Callable {
    String call();
}

package WorkingWithAbstractionExr.CardSuit;

public enum CardSuit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES

}

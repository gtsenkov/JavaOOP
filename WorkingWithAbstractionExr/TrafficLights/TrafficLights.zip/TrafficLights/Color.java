package WorkingWithAbstractionExr.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW

    //RED -> GREEN
    //GREEN -> YELLOW
    //YELLOW -> RED
}
